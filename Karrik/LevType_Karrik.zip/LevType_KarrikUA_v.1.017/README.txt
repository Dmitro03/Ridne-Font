﻿SIL Open Font License v1.1


Latin by Velvetyne / velvetyne.fr
Ukrainian Cyrillic by LevType / levtype.com


-
LevType. Ukrainian supported free fonts
 
(^･Ł･^)


www.levtype.com
behance.net/levtype
instagram.com/levtype
levtype.com@gmail.com


-
#helpukraine #standwithukraine