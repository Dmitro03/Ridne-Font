Free for personal and commercial use

The font cannot be sold; all modifications and derivatives must be distributed freely.

Buy a coffee:
https://boosty.to/pavljenko/donate

Follow:
http://designside.t.me/
https://www.instagram.com/pavljenko/